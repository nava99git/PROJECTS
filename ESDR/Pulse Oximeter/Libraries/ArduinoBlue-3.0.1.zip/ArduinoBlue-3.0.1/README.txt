Stable releases:
https://github.com/purwar2016/ArduinoBlue-library/releases

Tutorial (Beginner Friendly):
https://sites.google.com/stonybrook.edu/arduinoble/

Documentation:
https://github.com/purwar2016/ArduinoBlue-library/wiki/Documentation
