#ifndef FunctionType_h
#define FunctionType_h

typedef void(*functiontype)();
typedef void(*functiontypeint)(int);


#endif
